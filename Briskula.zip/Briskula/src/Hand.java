import java.util.ArrayList;

public class Hand {

	public ArrayList<Card> handCards;
	private int score = 0;
	
	Hand(Deck deck){
		handCards = new ArrayList<Card>();
		for(int i = 0; i < 3; i++) {
			handCards.add(deck.draw());
		}
	}
	
	public void handDraw(Deck deck) {
		handCards.add(deck.draw());
	}
	
	public Card handPlay(int index) {
		try {
			Card tmp = handCards.get(index);
			handCards.remove(index);
			return tmp;
			}
			catch(Exception ArgumentOutOfRangeException) {
			  return null;
			}
	}
	
	public void addPoints(int nPoints) {
		score += nPoints;
	}
	
	public int numCards() {
		return handCards.size();
	}
}
