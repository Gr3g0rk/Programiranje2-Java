import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

public class Deck {

	public ArrayList<Card> cards;
	
	Deck(){
		cards = new ArrayList<Card>();
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 10; j ++) {
				cards.add(new Card(i, j));
			}
		}
		Collections.shuffle(cards);
	}
	
	
	public Card draw() {
		Card tmp = cards.get(0);
		cards.remove(0);
		return tmp;
	}
	
	public int numCards() {
		return cards.size();
	}
}
