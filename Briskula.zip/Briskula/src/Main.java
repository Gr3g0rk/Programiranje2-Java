import java.util.ArrayList;
import java.util.Scanner;
public class Main {
	
	public static String[] suits = {"Spade", "Coppe", "Bastoni", "Danari"};
	public static String[] ranks = {"one", "three", "king", "knight", "jack", "7", "6", "5", "4", "2"};
	
	public Deck deck;
	public Card mainCard;
	public ArrayList<Hand> players;
	public int nPlayers = 2;
	
	
	
	public int startingPlayer;
	public boolean inPlay;
	
	Main(){
		startingPlayer = (int)(Math.random() * ((nPlayers - 1) + 1));
		inPlay = true;
		deck = new Deck();
		players = new ArrayList<Hand>();
		
		for(int i = 0; i < nPlayers; i++) {
			players.add(new Hand(deck));
		}
		mainCard = deck.draw();
	}
	
	public void leagalAction(Hand p) {
		if(p.numCards() == 0) this.inPlay = false;
	}
	
	public int compareCards(ArrayList<Card> pile, Card mainCard) {
		try {
		int winner = 0;
		for(int i=1; i<pile.size(); i++) {
			if(pile.get(i).getSuit() != mainCard.getSuit() && pile.get(i).getSuit() != pile.get(winner).getSuit()) continue;
			if(pile.get(i).getSuit() == mainCard.getSuit() && pile.get(winner).getSuit() != mainCard.getSuit()) winner = i;
			if(pile.get(winner).getSuit() == pile.get(i).getSuit()) {
				if(compareRanks(pile.get(winner), pile.get(i)) == -1) winner = i;	
			}
		}
		return winner;
	}catch(Exception e) {
		 return 0;
	}
		}
	
	public int compareRanks(Card a, Card b) {
		if(a.getRank() == b.getRank()) return 0;
		for(int i=0; i<ranks.length; i++) {
			if(ranks[i] == a.getRank()) return 1;
			if(ranks[i] == b.getRank()) return -1;
		}
		return 0;
	}
	
	public void resolvePile(ArrayList<Card> Pile, int p) {
		int winner = compareCards(Pile, this.mainCard);
		winner += p;
		if(winner >= this.nPlayers) {
			winner -= this.nPlayers;
		}
		this.players.get(winner).addPoints(1); //1 should be the N of points you get
		this.startingPlayer = winner;
	}

	public static void main(String args[])  //static method  
	{  

		
	}
}
