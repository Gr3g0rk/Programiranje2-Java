import java.util.ArrayList;

public class Card {

	private String rank, suit;
	public static String[] suits = {"Spade", "Coppe", "Bastoni", "Danari"};
	public static String[] ranks = {"one", "three", "king", "knight", "jack", "7", "6", "5", "4", "2"};
	
	Card(int suit, int rank){
		this.rank = ranks[rank];
		this.suit = suits[suit];
	}
	
	
	
	public String getRank() {
		return rank;
	}
	public String getSuit() {
		return suit;
	}
	public String getPath() {
		return "/cards_pics/"+this.suit+"_"+this.rank+".png";
	}
	
}
