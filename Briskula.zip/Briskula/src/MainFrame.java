import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainFrame extends JFrame {

	private JPanel contentPane;

	public Main game;
	public ArrayList<JButton> buttons = new ArrayList<JButton>();
	public int choice = -1;
	public boolean pressed = false;
	
	static JButton b0;
	static JButton b1;
	static JButton b2;
	static JButton b3;
	static JButton b4;
	static JButton b5;
	static boolean b1Clicked;
	static boolean b2Clicked;
	static boolean cont;
	
	public void CreateButtons() {
		ActionListener actionListener = e -> {
            Object source = e.getSource();
            if (source == b0 || source == b1 || source == b2 ) {
                b1Clicked = true;
                System.out.println("Player 1 clicked!");
                cont = true;
            }
            if (source == b3 || source == b4 || source == b5) {
                b2Clicked = true;
                System.out.println("Player 2 clicked!");
                cont = true;
            }
            if (b1Clicked && b2Clicked) {
                System.out.println("Both clicked!");
                b1Clicked = false;
                b2Clicked = false;
            }
        };
		
		b0 = new JButton("New button");
		b0.addActionListener(actionListener);
		b0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 0;
				pressed = true;
			}
		});
		b0.setBounds(10, 300, 80, 150);
		contentPane.add(b0);
		
		b1 = new JButton("New button");
		b1.addActionListener(actionListener);
		b1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 1;
				pressed = true;
			}
		});
		b1.setBounds(100, 300, 80, 150);
		contentPane.add(b1);
		
		b2 = new JButton("New button");
		b2.addActionListener(actionListener);
		b2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 2;
				pressed = true;
			}
		});
		b2.setBounds(190, 300, 80, 150);
		contentPane.add(b2);
		
		b3 = new JButton("New button");
		b3.addActionListener(actionListener);
		b3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 0;
				pressed = true;
			}
		});
		b3.setBounds(10, 11, 80, 150);
		contentPane.add(b3);
		
		b4 = new JButton("New button");
		b4.addActionListener(actionListener);
		b4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 1;
				pressed = true;
			}
		});
		b4.setBounds(100, 11, 80, 150);
		contentPane.add(b4);
		
		b5 = new JButton("New button");
		b5.addActionListener(actionListener);
		b5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				choice = 2;
				pressed = true;
			}
		});
		b5.setBounds(190, 11, 80, 150);
		contentPane.add(b5);
		
		JButton b6 = new JButton("Deck");
		b6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//System.out.print(game.deck.numCards());
			}
		});
		b6.setBounds(394, 160, 80, 150);
		contentPane.add(b6);
		
		JButton b7 = new JButton("MainCard");
		b7.setBounds(304, 160, 80, 150);
		contentPane.add(b7);
		
		buttons.add(b0);
		buttons.add(b1);
		buttons.add(b2);
		buttons.add(b3);
		buttons.add(b4);
		buttons.add(b5);
		buttons.add(b6);
		buttons.add(b7);
		
	}

	public void DrawButtons(Main game) {
		for(int i = 0; i < game.nPlayers; i ++) {
			for(int j = 0; j < 3; j++) {
				this.buttons.get(i*3 + j).setIcon(new javax.swing.ImageIcon(getClass().getResource(game.players.get(i).handCards.get(j).getPath())));
			}
		}
		this.buttons.get(7).setIcon(new javax.swing.ImageIcon(getClass().getResource(game.mainCard.getPath())));
	}
	
	public MainFrame() {

		setTitle("Briškula");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		CreateButtons();
		//DrawButtons();
	}
	
	
	public static void main(String[] args) throws InterruptedException {
		MainFrame frame = new MainFrame();
		frame.setVisible(true);
		
		Main game = new Main();
		Scanner myInput = new Scanner(System.in);
		System.out.print(game.startingPlayer);
		//frame.buttons.get(8).setIcon(new javax.swing.ImageIcon(getClass().getResource(game.mainCard.getPath())));

		while(game.inPlay) {
			ArrayList<Card> curPile = new ArrayList<Card>();
			frame.DrawButtons(game);
			System.out.println("First P: " + game.deck.numCards());
			System.out.println("First P: " + game.startingPlayer);
			
			for(int i=0; i<game.nPlayers; i++) {
				int p = i+game.startingPlayer; // če začne drugi da dejansko začne drugi
				if(p >= game.nPlayers) p = p - game.nPlayers; // ... do tuki dela
				
				////////////////////////////////////////////////////////////////////////////////////////
				// while (frame.pressed == false){ }
				
				
				while(!cont)
				{
				  Thread.sleep(10);
				}
				////////////////////////////////////////////////////////////////////////////////////////
				curPile.add(game.players.get(p).handPlay(frame.choice));
				System.out.println("done waiting");
				frame.pressed = false;
				frame.choice = -1;
				cont = false;
			}
			System.out.println("Resolving pile");
			game.resolvePile(curPile, game.startingPlayer); // ko oba data karto, najdem zmagovalca ...od tle dela
			
			for(int i = 0; i<game.nPlayers; i++) {
				game.players.get(i).handDraw(game.deck);
			}
			if(game.deck.numCards() < 3) {
				game.inPlay = false;
			}
		}	
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
